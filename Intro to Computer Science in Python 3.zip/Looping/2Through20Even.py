number = 2
while number <= 20:
    print(number)
    number = number + 2