my_float = 3.3312

# Your code here...
while True:
    guess = float(input("Guess the number: "))
    if round(guess, 2) == round(my_float, 2):
        print("Correct!")
        break
    if guess < my_float:
        print("Too low!")
    if guess > my_float:
        print("Too high!")