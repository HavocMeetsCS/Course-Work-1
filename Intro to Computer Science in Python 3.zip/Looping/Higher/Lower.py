magic_number = 3

# Your code here...
while True:
    guess = int(input("Guess the number: "))
    if guess == magic_number:
        print("Correct")
        break
    if guess < magic_number:
        print("Too low!")
    if guess > magic_number:
        print("Too high!")