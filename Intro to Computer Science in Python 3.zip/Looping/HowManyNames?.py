
count = int(input("Input how many names you have: "))
for i in range(1):
    name_one = "a"
    name_two = "a"
    name_three = "a"
    name_four = "a"
    name_five = "a"
    name_six = "a"
if count == 3:
    name_one = input("Input: ")
    name_two = input("Input: ")
    name_three = input("Input: ")
    print(name_one+ " " + name_two+ " " + name_three+ " ")
if count == 6:
    name_one = input("Input: ")
    name_two = input("Input: ")
    name_three = input("Input: ")
    name_four = input("Input: ")
    name_five = input("Input: ")
    name_six = input("Input: ")
    print(name_one + " " + name_two +" "  + name_three+ " " + name_four+ " " + name_five + " " + name_six)