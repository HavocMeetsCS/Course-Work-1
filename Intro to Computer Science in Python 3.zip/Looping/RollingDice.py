for i in range(1,7):
    for j in range(1,7):
        print(str(i) + "," + str(j))