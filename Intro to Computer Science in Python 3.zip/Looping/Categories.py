for i in range(3):
    category = input("Input a Category:")
    item = input("Input a item in that category")
    itemn = input("Input a item in that category")
    itemb = input("Input a item in that category")
    print(category + ": " + item + " " + itemn + " " + itemb )