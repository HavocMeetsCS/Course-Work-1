# See if you can guess what this program prints!
x = 10

while x > 5:
    print(x)
    x = x - 2