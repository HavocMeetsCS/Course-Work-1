math = 0
for i in range(10):
    math = math + 10
    print(math)