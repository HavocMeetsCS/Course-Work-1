for i in range(1):
    grade_one = float(input("input 1 grade:"))
grade_two = float(input("input 1 grade:"))
grade_three = float(input("input 1 grade:"))
vale = grade_one + grade_two + grade_three
vale = vale * 1/3
print(vale)