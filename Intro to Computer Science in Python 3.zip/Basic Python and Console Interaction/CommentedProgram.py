"""
This program asks the user for a number. It then
prints the result when that number is multiplied
by two.
"""

# Ask the user for a number
number = int(input("Enter a number: "))

# print the number, doubled
print("Twice that number is: " + str(number * 2))