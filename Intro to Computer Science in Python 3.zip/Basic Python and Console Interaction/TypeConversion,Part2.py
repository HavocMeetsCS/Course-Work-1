x = int(input("Enter a number: "))
print(type(x))
print(x)
print(x + 3)