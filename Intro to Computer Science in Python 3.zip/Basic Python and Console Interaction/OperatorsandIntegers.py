x = 4
y = 5
z = 6

print("x + y:")
print(x + y)
print(" ")
print("z * 3:")
print(z * 3)
print(" ")
print("x - z:")
print(x - z)
print(" ")
print("z / x:")
print(z / x)
print(" ")
print("y ** x:")
print(y ** x)
print(" ")
print("z % y:")
print(z % y)
print(" ")
print("-x:")
print(-x)