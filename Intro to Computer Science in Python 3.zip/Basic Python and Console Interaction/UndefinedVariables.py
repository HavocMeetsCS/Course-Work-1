a = 10
print(a)
c = 20
b = c
d = a + b
e = c + d
print(b)
print(c)
print(d)
print(e)