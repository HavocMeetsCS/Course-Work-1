text = input("Enter something: ")
print(text)
print(type(text))