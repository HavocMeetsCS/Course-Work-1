print(type(2))
print(type("Hi"))

print("-----")

pi = 3.14
initial = "c"

print(type(pi))
print(type(initial))