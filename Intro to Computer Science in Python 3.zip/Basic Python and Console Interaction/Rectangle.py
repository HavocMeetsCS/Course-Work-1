length = 10
width = 5
area = length * width
perimeter = width * 2 + length * 2
print(area)
print(perimeter)