length = 0
width = 0
length = int(input(" How long should the length be? "))
width = int(input("how long should the width be? "))
area = length * width
perimeter = width * 2 + length * 2
print("The area is " + str(area))
print(" The perimeter is " + str(perimeter))