length = 10
width = 5
area = length * width
perimeter = width * 2 + length * 2
print("The area is" + str(area))
print(" The perimeter is" + str(perimeter))