name = "Tricia"
print("Name")
print("-----")
print(name)
print("-----")

height_in_cm = 175
print("Height in centimeters")
print("-----")
print(height_in_cm)
print("-----")

company = "Google"
print("Company")
print("-----")
print(company)
print("-----")

favorite_cereal = "Raisin Bran"
print("Favorite cereal")
print("-----")
print(favorite_cereal)
print("-----")