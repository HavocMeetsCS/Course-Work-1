print("Hi there!")
print("My favorite color is magenta.")