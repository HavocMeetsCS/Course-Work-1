blank = int(input(" How old are you?"))
blank = blank + 1
print("You blank need Candles for your birthday: ")
print(blank)