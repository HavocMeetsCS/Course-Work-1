print("Kevin")
print("100")