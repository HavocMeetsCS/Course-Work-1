"""
This program asks the user for three ingredients,
three amounts, and a number of servings, and
determines how much of each ingredient is needed
to serve the specified number of servings.
"""

# Write program here...
ingredient_one = input("What ingredient is the first?  ")
ingredient_one_number = float(input("How many ounces of it for the salad? "))
ingredient_two = input("What ingredient is the second?  ")
ingredient_two_number = float(input("How many ounces of it for the salad? "))
ingredient_three = input("What ingredient is the third?  ")
ingredient_three_number = float(input("How many ounces of it for the salad? "))
flop = int(input(" Number of servings? "))
ingredient_one_number = ingredient_one_number * flop
ingredient_two_number = ingredient_two_number * flop
ingredient_three_number = ingredient_three_number * flop
print(" Ingredient " + str(ingredient_one) + " ounces " + str(ingredient_one_number))
print(" Ingredient " + str(ingredient_two) + " ounces " + str(ingredient_two_number))
print(" Ingredient " + str(ingredient_three) + " ounces " + str(ingredient_three_number))