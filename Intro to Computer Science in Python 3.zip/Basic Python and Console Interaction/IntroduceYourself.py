print("My name is Kevin")
print(" I like idk")