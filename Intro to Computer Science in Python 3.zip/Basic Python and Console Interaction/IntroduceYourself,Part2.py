name = ("Kevin")
age = 15
print("My name is " + name + " I am " + str(age) + " years old")