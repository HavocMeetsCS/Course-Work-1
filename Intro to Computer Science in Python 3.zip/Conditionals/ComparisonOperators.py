x = 10
y = 5

print("x is " + str(x))
print("y is " + str(y))

print("Is x equal to y?")
print(x == y)

print("Is x not equal to y?")
print(x != y)

print("Is x less than y?")
print(x < y)

print("Is x greater than y?")
print(x > y)

print("Is x less than or equal to y?")
print(x <= y)

print("Is x greater than or equal to y?")
print(x >= y)