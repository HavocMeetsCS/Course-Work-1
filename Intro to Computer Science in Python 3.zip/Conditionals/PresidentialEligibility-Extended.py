"""
living = int(input("Term of Residency: "))
age = int(input("Input your age: "))
nation = input("Are you American (Yes)(No): ")
if living > 14 and age > 35 and nation == "Yes":
    print("You are eligible to run for Office")
if nation != "Yes":
    print("You Need to Be american")
if age < 35:
    print("To young")
if living < 14 and nation == "Yes":
    print("You have not lived in the US long enough")
else:
    print("Error")
"""
Age = int(input("Age: "))

BornLocation = str(input("Born in the U.S.?(Yes/No): "))

Year = int(input("Years of Residency: "))



if Age>=35 and BornLocation=="Yes" and Year>=14:
    print("You are eligible to run for president!")

else:
    print("You are not eligible to run for president.")

if Age<35:
    print("You are too young. You must be at least 35 years old.")

if BornLocation=="No":
    print("You must be born in the U.S. to run for president.")

if Year<14:
    print("You have not been a resident for long enough.")