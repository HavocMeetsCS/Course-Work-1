reservation_name = "Hook"
check_in =input("Enter your name:")
if check_in == reservation_name:
    print("Right this way!")
else:
    print("Invalid Please Try Again")