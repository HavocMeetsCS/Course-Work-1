rain = True
if rain:
    print(" You should dance in the rain")
else:
    print("No dancing")