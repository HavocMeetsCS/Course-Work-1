age = int(input("Input age"))
if age >= 18:
    print("Old Enough to vote")
else:
    print("Not Old Enough to vote.")