# This program simulates a single transaction -
# either a deposit or a withdrawal - at a bank.
dog = False
you = False
balance = 1000
dep_two = 0
end = 0
value = True
test = True

dep = input("WITHDRAW to withdrawal, DEPOSIT to deposit ")

if dep == "withdrawal":
    dog = True
    test = False

if dep == "deposit":
    you = True
    test = False

if test:
    print("Invalid transaction")
    dep = input("WITHDRAW to withdrawal, DEPOSIT to deposit ")

dep_two = float(input("Input the Number you want to Withdraw or Deposit: "))

if dog:
    end = balance - dep_two
if you:
    end = balance + dep_two

if end < 0:
    print("You cannot have a negative balance!")
    value = False

if value:
    print("Balance: $"+str(end))