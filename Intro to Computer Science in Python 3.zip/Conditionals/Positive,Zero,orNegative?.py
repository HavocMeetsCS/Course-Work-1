number = int(input("Input a Number: "))
if number >= 0:
    print("Positive")
if number == 0:
    print("Zero")
else:
    print("Negative")