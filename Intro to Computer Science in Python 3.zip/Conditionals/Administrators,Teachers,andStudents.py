test = input("You can only be an administrator, teacher, or student!")
if test == "teacher" or test == "adminstrator":
    print("Administrators and teachers get keys!")
elif test == "student":
    print("Students do not get keys!")
else:
    print("You can only be an administrator, teacher, or student!")