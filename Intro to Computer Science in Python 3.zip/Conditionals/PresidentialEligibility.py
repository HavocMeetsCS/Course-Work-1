citizen = input("Are you a US citizen? ")
age = 16
if citizen == "Yes":
    citizen = 0
required = 35
lol = 0
if age > required and citizen == lol:
    print("You are eligible to run for president.")
else:
    print("You are not eligible to run for president.")