# update the function to return `word` with all instances of `letter` removed!
def remove_all_from_string(word, letter):
    return word.strip(letter)

remove_all_from_string("haus", "h")
