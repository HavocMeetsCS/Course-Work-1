# fill in the body of this function!
def initials(first, last):
    return first[0] + "." + last[0] + "."