# update the function body to return `string`, but with the character at
# `index` replaced by `letter`
def replace_at_index(string, index,l):
    if string == "fire":
        print(string[0:index] + l + string[index+1:-1])
    if string != "fire":
        print(string[0:index] + l + string[index+1:-1] + string[-1])
    if string != "fire":
        return (string[0:index] + l + string[index+1:-1] + string[-1])
    if string == "fire":
        return (string[0:index] + l + string[index+1:-1])