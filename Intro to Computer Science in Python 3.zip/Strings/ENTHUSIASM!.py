# return the input capitalized and with an exclamation point!
def add_enthusiasm(string):
    return string.upper() + "!"