# update the function body to return the input `string` 
# with the character at `index` replaced with a dash (-)
def replace_at_index(string, index):
    print(string[0:index] + "-" + string[index+1:-1] + string[-1])
    return (string[0:index] + "-" + string[index+1:-1] + string[-1])