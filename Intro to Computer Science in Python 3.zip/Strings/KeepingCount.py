def count_occurrences(word, character):
    y = 0
    for letter in word:
        if letter == character:
            y = y + 1
    return (y)