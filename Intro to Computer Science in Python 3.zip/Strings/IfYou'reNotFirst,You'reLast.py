# update the function body to return everything but the first letter
def end_of_word(word):
    return word[1:9]