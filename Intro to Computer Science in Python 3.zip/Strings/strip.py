"""
This program uses the strip method which returns a new string equal to the
old string with leading and trailing whitespace characters (spaces, tabs, etc.)
removed.
"""

s = "      ...hi...?      "
print(s)
print(s.strip())