def contains_vowel(word):
    run = True
    for i in range(len(word)):
        if word[i] == "a":
            print("True")
            return True
            run = False
        if word[i] == "e":
            print("True")
            return True
            run = False
        if word[i] == "i":
            print("True")
            return True
            run = False
        if word[i] == "o":
            print("True")
            return True
            run = False
        if word[i] == "u":
            print("True")
            return True
            run = False
    if run:
        print("False")
        return False