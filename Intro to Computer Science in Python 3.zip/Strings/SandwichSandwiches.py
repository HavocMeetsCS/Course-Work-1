# update the function's body to return the 
# first and last letter of the input concatenated together
lol = 0
def sandwich(lol):
    return lol[0] + lol[-1]