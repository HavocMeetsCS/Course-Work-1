word = "eggplant"
run = True
# Give the word to spell
print("Your word is: " + word + ".")
num = 0
# Spell the word with a for loop here!
for letter in word:
    print(letter + "!")