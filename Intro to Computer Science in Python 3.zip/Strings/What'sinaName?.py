# fill in the arguments and function body
def name_contains(string,char):
    print(string.find(char))
    if string.find(char) > 0:
        return True
    if string.find(char) < 0:
        return False