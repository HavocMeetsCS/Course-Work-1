# fill in this function to greet the user!
def greeting(user_info):
    listx = user_info.split()
    name = str(listx[:1])
    hobby = str(listx[2:3])
    hobby = hobby.strip("']")
    hobby = hobby.strip("['")
    name = name.strip("']")
    name = name.strip("['")    
    return "Hello, " + name + "!" + " I also enjoy " + hobby + "!"