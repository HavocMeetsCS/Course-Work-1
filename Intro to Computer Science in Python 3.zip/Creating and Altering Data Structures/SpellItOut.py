# fill in this function to return a list containing each character in the name
def spell_name(name):
    abc = list(name)
    return abc