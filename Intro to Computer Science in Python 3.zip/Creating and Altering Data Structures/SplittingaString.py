"""
This program will turn a phrase into a list by separating elements at
the whitespace (or spaces) entered.
"""

my_string = "try to be a rainbow in someone's cloud"
print(my_string)

my_list = my_string.split()
print(my_list)