# your function should return the maximum value in `my_list`
def max_int_in_list(my_list):
    return 0