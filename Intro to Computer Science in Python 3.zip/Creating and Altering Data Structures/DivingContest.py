# fill in this function to return the total of the three judges' scores!
def calculate_score(judge_scores):
    first, middle, last = judge_scores
    x = last + first + middle
    return x