my_tuple = (0, 1, 2, "hi", 4, 5)
test = (3,)
# Your code here...

print(my_tuple[0:3] + test + my_tuple [4:6])