"""
This program shows the different ways to index a tuple.
"""

my_tuple = (1, 2, 3, 4, 5)

print(my_tuple[0])

print(my_tuple[:2])

print(len(my_tuple))

# -- THE LINE BELOW WOULD CAUSE AN ERROR --
# my_tuple[0] = 10