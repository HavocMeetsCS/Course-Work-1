"""
1. draw a circle
2. figure out how to multiply the cirles radius
"""
#movment so they look centered
def movement_part():
    penup()
    right(90)
    forward(25)
    left(90)
circle_radius = 25
circle(circle_radius)
# for i in range uses a variable.
for i in range(3):
    movement_part()
    circle_radius = circle_radius + 25
    pendown()
    circle(circle_radius)