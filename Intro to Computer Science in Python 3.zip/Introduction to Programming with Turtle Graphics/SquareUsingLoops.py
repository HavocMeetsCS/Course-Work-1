for i in range(4):
    forward(50)
    left(90)