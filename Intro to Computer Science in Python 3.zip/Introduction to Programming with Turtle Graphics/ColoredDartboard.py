print("Hello, If you do not pick a color it will default to black :) ")
penup()
right(90)
forward(100)
left(90)
pendown()
radius = 100
for i in range(4):
    pendown()
    color_choice = input("What color should the circle be? ")
    color(color_choice)
    begin_fill()
    circle(radius)
    radius = radius - 25
    end_fill()
    penup()
    left(90)
    forward(25)
    right(90)