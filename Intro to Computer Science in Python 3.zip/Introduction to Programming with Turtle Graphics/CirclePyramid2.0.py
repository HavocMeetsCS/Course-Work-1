virgin = 0
radius = 25
setposition(-180,-200)
clear()
row_value = int(input("How many rows of circles do you want? (Less then 8) "))
if row_value >= 8:
    row_value = int(input("How many rows of circles do you want? (Less then 8) "))
def circle_row():
    for i in range(row_value):
        pendown()
        circle(radius)
        penup()
        forward(radius*2)
        pendown()
circle_row()
for i in range(row_value):
    left(90)
    penup()
    forward(radius*2)
    left(90)
    forward(row_value*45)
    left(180)
    row_value = row_value - 1
    circle_row()