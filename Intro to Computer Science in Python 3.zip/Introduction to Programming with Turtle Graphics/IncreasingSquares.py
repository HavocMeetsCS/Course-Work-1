"""
werid advance circle method?
"""
penup()
setposition(25,25)
penup()
speed(5)
right(90)
forward(50)
left(90)
backward(50)
length = 50

while length < 400:
    pendown()
    for i in range(4):
        forward(length)
        left(90)
    length = length + 50
    penup()
    right(90)
    forward(25)
    right(90)
    forward(25)
    right(180)
setposition(25,25)
pendown()
for i in range(2):
    forward(50)
    left(90)