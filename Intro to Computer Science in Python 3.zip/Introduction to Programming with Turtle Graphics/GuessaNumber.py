def green_sucess():
    color("green")
    left(90)
    pensize(10)
    pendown()
    left(45)
    forward(50)
    backward(50)
    right(90)
    forward(100)
secret_number = 8
user_number = 0
def help():
    user_number = int(input("What is the Secret Number 1-10: "))
    if user_number == secret_number:
        green_sucess()
    else:
        help()
help()