"""
This script is designed to be used in order to make a pyrimad full of circles
Farther comments are below
"""
circle(50)

penup()
setposition(-100,-200)

#to work on the 3rd layer
for i in range(3):
    pendown()
    circle(50)
    penup()
    forward(100)

setposition(-50,-100)

# To work on the the 2nd layer
for i in range(2):
    pendown()
    circle(50)
    penup()
    forward(100)