"""
circle and square pattern
"""
penup()
setposition(0,-200)
#Square pattern to make a square when called on
def square_pattern():
    for i in range(2):
        pendown()
        forward(50)
        left(90)
        forward(50)
        left(90)
def circle_pattern():
    circle(25)
    penup()
    forward(100)
    pendown()
    
speed(0)
left(90)
for i in range(4):
    square_pattern()
    penup()
    forward(100)
left(180)
forward(25)
pendown()
for i in range(4):
    circle_pattern()