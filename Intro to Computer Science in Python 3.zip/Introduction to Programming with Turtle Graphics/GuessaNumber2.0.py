def green_sucess():
    color("green")
    left(90)
    pensize(10)
    pendown()
    left(45)
    forward(50)
    backward(50)
    right(90)
    forward(100)
def up_arrow():
    color("yellow")
    left(90)
    pensize(10)
    pendown()
    forward(100)
    left(135)
    forward(50)
    backward(50)
    right(270)
    forward(50)
def down_arrow():
    color("yellow")
    left(90)
    pensize(10)
    pendown()
    forward(-100)
    left(135)
    forward(-50)
    backward(-50)
    right(90)
    forward(50)
secret_number = 8
user_number = 0
def help():
    user_number = int(input("What is the Secret Number 1-10: "))
    if user_number == secret_number:
        green_sucess()
    elif user_number > secret_number:
        up_arrow()
    elif user_number < secret_number:
        down_arrow()
    else:
        help()
help()