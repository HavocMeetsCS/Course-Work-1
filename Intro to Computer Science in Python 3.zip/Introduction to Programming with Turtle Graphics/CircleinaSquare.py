speed(0)
radius = int(input(" What should the radius be? "))
penup()
setposition(0,-200)
def red_square():
    pendown()
    color("red")
    begin_fill()
    for i in range(4):
        for i in range(2):
            forward(radius)
        left(90)
        for i in range(2):
            forward(radius)
    end_fill()
    penup()
"""
Hello, Yes I do know the circle does not look like the photo i did and it made
wrong so.. SOrry!
"""
def blue_circle():
    pendown()
    color("blue")
    begin_fill()
    circle(radius)
    end_fill()
red_square()
blue_circle()