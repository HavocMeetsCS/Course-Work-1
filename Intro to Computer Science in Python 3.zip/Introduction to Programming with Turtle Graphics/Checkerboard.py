speed(0)
colorvalue = 0
if colorvalue % 2 == 0:
    color("red")
if colorvalue % 2 == 1:
    color("black")
penup()
setposition(-200,-200)
def square():
    begin_fill()
    for i in range(4):
        forward(40)
        left(90)
    end_fill()
    forward(40)
pendown()
def color_row_num_two():
    pendown()
    for i in range(10):
        square()
        if i % 2 == 0:
            color("red")
        if i % 2 == 1:
            color("black")
    penup()
    left(90)
    forward(40)
    left(90)
    forward(400)
    left(180)
    if color("red"):
        color("black")
    else:
        color("red")    
def color_row_num_one():
    pendown()
    for i in range(10):
        square()
        if i % 2 == 0:
            color("black")
        if i % 2 == 1:
            color("red")
    penup()
    left(90)
    forward(40)
    left(90)
    forward(400)
    left(180)
    if color("red"):
        color("black")
    if color("black"):
        color("red")
for i in range(5):
    color_row_num_one()
    color_row_num_two()