penup()
setposition(-200,-200)
#box is on quack
def row_of_square_box():
    for i in range(4):
        pendown()
        forward(50)
        left(90)
    penup()
    forward(50)
for i in range(2):
    for i in range(8):
        row_of_square_box()
    left(90)
    forward(50)
    for i in range(7):
        row_of_square_box()
    left(90)