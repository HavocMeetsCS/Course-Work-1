snow_man_radius = int(input("What should the Radius of the snow man be? "))
penup()
setposition(0,-200)
pendown()
color("grey")
def snow_man_sos_lol():
    begin_fill()
    circle(snow_man_radius)
    end_fill()
    left(90)
    forward(snow_man_radius)
    forward(snow_man_radius)
    right(90)
snow_man_sos_lol()
snow_man_radius = snow_man_radius * 0.50
snow_man_sos_lol()
snow_man_radius = snow_man_radius * 0.50
snow_man_sos_lol()