penup()
setposition(-200,-200)
print("only input numbers>>")
square_length = int(input("How long should this square length be? "))
def square_lord():
    for i in range(4):
        pendown()
        forward(square_length)
        left(90)
        penup()
for i in range(3):
    square_lord()
    forward(350)
    square_lord()
    forward(50)
    left(90)