"""
This goal is to make a circle with many circles
"""
#Function is going to be for the loop
def circle_circle_many(): 
   for i in range(36):
        circle(10)
        left(10)
        penup()
        forward(20)
        pendown()
speed(0)
penup()
setposition(0,-100)
pendown()
circle_circle_many()
penup()
setposition(0,-100)