
penup()
setposition(-170,0)
def circle_i_pray_to_god_this_works(color_choice):
    pendown()
    begin_fill()
    color(color_choice)
    circle(15)
    end_fill()
    penup()
    forward(30)
for i in range(2):
    color_choice = "blue"
    circle_i_pray_to_god_this_works(color_choice)
    color_choice = "green"
    circle_i_pray_to_god_this_works(color_choice)    
    color_choice = "gold"
    circle_i_pray_to_god_this_works(color_choice)
    color_choice = "yellow"
    circle_i_pray_to_god_this_works(color_choice)
"""
penup()
setposition(-170,0)
color_choice = color("black")
# I like the name of color alternator and it was a pain to make, Note: HELLO
def circle_alternator_circle1():
    pendown()
    begin_fill()
    color(color_choice1)
    circle(15)
    end_fill()
    penup()
    forward(30)
def circle_alternator_circle2():
    pendown()
    begin_fill()
    color(color_choice2)
    circle(15)
    end_fill()
    penup()
    forward(30)
def circle_alternator_circle3():
    pendown()
    begin_fill()
    color(color_choice3)
    circle(15)
    end_fill()
    penup()
    forward(30)
def circle_alternator_circle4():
    pendown()
    begin_fill()
    color(color_choice4)
    circle(15)
    end_fill()
    penup()
    forward(30)
color_choice1 = input("What color should the next circle be? ")
color_choice2 = input("What color should the next circle be? ")
color_choice3 = input("What color should the next circle be? ")
color_choice4 = input("What color should the next circle be? ")
for i in range(2):
    circle_alternator_circle1()
    circle_alternator_circle2()
    circle_alternator_circle3()
    circle_alternator_circle4()
"""