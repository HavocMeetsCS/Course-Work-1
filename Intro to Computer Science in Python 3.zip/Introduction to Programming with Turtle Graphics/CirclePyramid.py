circle(50)
penup()
setposition(-100,-200)
for i in range(3):
    pendown()
    circle(50)
    penup()
    forward(100)
setposition(-50,-100)
for i in range(2):
    pendown()
    circle(50)
    penup()
    forward(100)