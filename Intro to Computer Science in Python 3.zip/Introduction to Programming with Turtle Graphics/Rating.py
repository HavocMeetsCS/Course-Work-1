rating = int(input("What is Tracys Review? "))
penup()
def red_x():
    color("red")
    pensize(10)
    pendown()
    left(45)
    for i in range(2):
        left(90)
        forward(25)
        backward(50)
        forward(25)
def yellow_depress():
    color("yellow")
    pensize(10)
    pendown()
    backward(50)
    forward(100)
def green_sucess():
    color("green")
    left(90)
    pensize(10)
    pendown()
    left(45)
    forward(50)
    backward(50)
    right(90)
    forward(100)
if 1 <= rating <= 4:
    red_x()
elif 4 < rating <= 7:
    yellow_depress()
elif rating >= 8:
    green_sucess()
# I regret nothing>>
else:
    print("your dumb")