"""
FIGURE OUT HOW TO MULTIPLY LENGTH OF CIRCLES AND DISTANCE
"""
penup()
setposition(-150,0)
box_support = 10
def box_base():
    for i in range(4):
        pendown()
        forward(box_support)
        left(90)
        penup()

box_base()
for i in range(4):    
    box_support = box_support + 10
    forward(box_support)
    box_base()