penup()
setposition(-150,0)
def square_alternator():
    pendown()
    count = 0
    for i in range(7):
        if count % 2 >= 1:
            begin_fill()
            left(45)
            circle(25,360,4)
            right(45)
            penup()
            forward(50)
            pendown()
            end_fill()
        if count % 2 == 0:
            left(45)
            circle(25,360,4)
            right(45)
            penup()
            forward(50)
            pendown()
        count = count + 1
square_alternator()