# Write your function for converting Celsius to Fahrenheit here.
# Make sure to include a comment at the top that says what
# each function does!


f = 0
c = 0

# Now write your function for converting Fahrenheit to Celsius.

def funo(f):
    c = (f-32) / 1.8
    print(c)
    return(c)
def uno(c):
    f = (c * 1.8) + 32
    print(f)
    return(f)
# Now change 0C to F:
uno(0)

# Change 100C to F:
uno(100)

# Change 40F to C:
funo(40)

# Change 80F to C:
funo(80)