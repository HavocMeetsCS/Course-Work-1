num1 = 10
def mok():
    y = int(input("Input a number"))
    print(y + num1)
# Your code here...
mok()