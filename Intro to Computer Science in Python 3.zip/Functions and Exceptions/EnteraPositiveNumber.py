y = 0
run = True
def retrieve_positive_number():
    try:
        y = int(input("Input a positive number"))
    except ValueError:
        prin("Error")
while run:
    retrieve_positive_number()