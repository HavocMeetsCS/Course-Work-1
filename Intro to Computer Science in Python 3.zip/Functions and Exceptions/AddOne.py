def lol(x):
    x + 1
    return x
lol(1)
print(lol(1))