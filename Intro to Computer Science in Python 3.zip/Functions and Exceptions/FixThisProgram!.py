"""
This program takes two values and prints their sum.
"""

def add_nums(num1, num2):
    sum = num1 + num2
    print(sum)
add_nums(5, 6)