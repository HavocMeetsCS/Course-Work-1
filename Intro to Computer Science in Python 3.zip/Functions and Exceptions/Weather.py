weathere = input("What is the curreny weather (rainy,snowy,sunny): ")
def weather():
    print("you should wear sandals")
def rainy():
    print("you should wear galoshes")
def snowy():
    print("you should wear boots")
if weathere == "sunny":
    weather()
if weathere == "rainy":
    rainy()
if weathere == "snowy":
    snowy()