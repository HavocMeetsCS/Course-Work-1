def subtract():
    print(str(x) + " - " + str(y) + " = " + str(x-y))
def multiply():
    print(str(x) + " * " + str(y) + " = " + str(x*y))
def add():
    print(str(x) + " + " + str(y) + " = " + str(x+y))
x = int(input(" Input a number"))
y = int(input(" Input a number"))
z  = input("subtract,add,multiply: ")
if z == "subtract":
    subtract()
if z == "multiply":
    multiply()
if z == "add":
    add()