def prit(x,y):
    print(x + y)
prit(1,3)