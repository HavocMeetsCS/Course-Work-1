def pint(x,y):
    for i in range(y):
        print(x)
pint("hi",3)