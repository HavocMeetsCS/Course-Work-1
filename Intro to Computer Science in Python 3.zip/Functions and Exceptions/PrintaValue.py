# This function takes a single parameter and prints it.

def print_value(x):
    print(x)

print_value(12)
print_value("dog")