
def lol(x,y):
    return x + 1 + y
print(lol(1,2))