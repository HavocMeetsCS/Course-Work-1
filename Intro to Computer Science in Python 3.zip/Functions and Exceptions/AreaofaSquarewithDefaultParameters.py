y = 1
def calculate_area(side_length = 10):
    if side_length <= 0:
        calculate_area(side_length = 10)
    area = side_length * side_length
    if side_length > 0:
        print("The area of a square with sides of length " + str(side_length) + " is " + str(area))
calculate_area(int(input("Input length: ")))